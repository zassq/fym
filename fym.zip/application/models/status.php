<?php

class Status extends MY_Model{
	const DB_TABLE = 'status';
	const DB_TABLE_PK = 'id';

	public $id;

	public $status;
}

?>