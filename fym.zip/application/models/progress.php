<?php

class Progress extends MY_Model{
	const DB_TABLE = 'progress';
	const DB_TABLE_PK = 'id';

	public $id;

	public $progress;
}

?>