<?php

$lang['scaff_view_records']		= '查看记录';
$lang['scaff_create_record']	= '创建新纪录';
$lang['scaff_add']				= '添加数据';
$lang['scaff_view']				= '查看数据';
$lang['scaff_edit']				= '编辑';
$lang['scaff_delete']			= '删除';
$lang['scaff_view_all']			= '查看所有';
$lang['scaff_yes']				= '是';
$lang['scaff_no']				= '否';
$lang['scaff_no_data']			= '此表中没有数据.';
$lang['scaff_del_confirm']		= '你确认要删除下列记录:';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/chinese/scaffolding_lang.php */